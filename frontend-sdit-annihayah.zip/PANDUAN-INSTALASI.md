# Panduan Instalasi — Sistem Administrasi & Arsip Sekolah SDIT Annihayah

Arsitektur: **Frontend (GitHub Pages)** ↔ fetch JSON ↔ **Backend (Google Apps Script REST API)**

---

## BAGIAN 1 — BACKEND (Google Apps Script)

1. Buka https://script.google.com → **Proyek Baru**
2. Hapus isi default `Code.gs`, ganti nama file jadi `Kode`, lalu **paste** seluruh isi file `Kode.gs` yang diberikan terpisah di chat.
3. Di dropdown fungsi (atas), pilih **`setupAppEnvironment`** → klik ▶ **Run**.
   - Klik **Review permissions** → izinkan akses Drive & Sheets (akun Google Anda sendiri).
   - Buka **Execution Log** (Ctrl+Enter), pastikan muncul:
     - `✅ Setup selesai!`
     - `✅ Login default -> username: admin | password: admin123 (SEGERA GANTI!)`
   - Cek Google Drive Anda: folder **"SDIT Annihayah - Sistem Sekolah"** sudah terbuat, berisi Spreadsheet database + folder Uploads & Exports.
   - ⚠️ **JANGAN jalankan `setupAppEnvironment()` lebih dari sekali** — akan membuat folder & sheet duplikat.
4. **Deploy** → **New deployment** → pilih tipe **Web app**:
   - Execute as: **Me**
   - Who has access: **Anyone**
   - Klik **Deploy** → **copy URL yang berakhiran `/exec`**
5. Simpan URL itu — akan dipakai di langkah frontend.
6. **Segera login dan ganti password default `admin123`** setelah aplikasi jalan (lewat menu Pengaturan/Users — tambahkan fitur ganti password bila belum ada).

## BAGIAN 2 — FRONTEND (GitHub Pages)

Folder frontend ini (`index.html`, `css/`, `js/`) sudah dalam struktur siap-push:

```
(folder ini adalah root repo Anda)
├── index.html
├── css/
│   └── style.css
└── js/
    ├── config.js
    ├── api.js
    └── app.js
```

**Langkah:**
1. Buka `js/config.js`, ganti baris:
   ```js
   const GAS_URL = 'https://script.google.com/macros/s/GANTI_DENGAN_DEPLOYMENT_ID/exec';
   ```
   dengan URL `/exec` dari Bagian 1 Langkah 4.
2. Ikuti panduan **github-pages-deploy-guide** untuk push folder ini (isi ZIP, bukan folder pembungkusnya) ke repository GitHub baru, lalu aktifkan **GitHub Pages** (Settings → Pages → Deploy from branch `main`, folder `/root`).
3. Buka `https://USERNAME.github.io/NAMA-REPO/` — halaman login akan muncul.
4. Login dengan `admin` / `admin123`, lalu segera ganti password.

## BAGIAN 3 — TEST

1. Login berhasil → Dashboard tampil dengan statistik (awalnya 0 karena belum ada data).
2. Buka menu **Siswa** → klik **+ Tambah Siswa** → isi form → **Simpan**. Cek Spreadsheet: baris baru muncul di sheet `Master_Siswa`.
3. Buka DevTools (F12) → tab Network → pastikan tidak ada error CORS saat request ke `/exec`.

## Status Pengembangan

Modul yang **sudah berfungsi penuh**: Login (dengan role & sesi), Dashboard statistik, Data Siswa (tambah + cari + tabel).

Modul dengan **backend API sudah siap** di `Kode.gs` namun **UI frontend masih placeholder** (tinggal dibuat halamannya mengikuti pola `renderSiswa()` di `app.js`): Nilai Rapor, Absensi, Catatan, Surat Masuk/Keluar, Riwayat Alumni, Pengaturan, Import/Export Excel, Cetak PDF.

Lihat komentar di `Kode.gs` dan `app.js` — setiap modul baru cukup:
1. Tambah `case` baru di `doGet`/`doPost` (backend sudah ada polanya).
2. Tambah fungsi `renderXxx()` baru di `app.js` mengikuti pola `renderSiswa()`.
3. Daftarkan di objek `MENU` dan `renderers` di `app.js`.
